-- -----------------------------
-- Think MySQL Data Transfer 
-- 
-- Host     : localhost
-- Port     : 3306
-- Database : wx
-- 
-- Part : #1
-- Date : 2020-08-19 16:59:42
-- -----------------------------

SET FOREIGN_KEY_CHECKS = 0;


-- -----------------------------
-- Table structure for `think_admin`
-- -----------------------------
DROP TABLE IF EXISTS `think_admin`;
CREATE TABLE `think_admin` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(20) COLLATE utf8_bin DEFAULT '' COMMENT '用户名',
  `password` varchar(32) COLLATE utf8_bin DEFAULT '' COMMENT '密码',
  `portrait` varchar(100) COLLATE utf8_bin DEFAULT NULL COMMENT '头像',
  `loginnum` int(11) DEFAULT '0' COMMENT '登陆次数',
  `last_login_ip` varchar(255) COLLATE utf8_bin DEFAULT '' COMMENT '最后登录IP',
  `last_login_time` int(11) DEFAULT '0' COMMENT '最后登录时间',
  `status` int(1) DEFAULT '0' COMMENT '状态',
  `groupid` int(11) DEFAULT '1' COMMENT '用户角色id',
  `token` varchar(32) COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- -----------------------------
-- Records of `think_admin`
-- -----------------------------
INSERT INTO `think_admin` VALUES ('1', 'admin', '218dbb225911693af03a713581a7227f', '', '4', '219.137.140.117', '1597826107', '1', '1', '1ac2fc424c64cdf80db98a246f439287');

-- -----------------------------
-- Table structure for `think_article`
-- -----------------------------
DROP TABLE IF EXISTS `think_article`;
CREATE TABLE `think_article` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `e` int(10) NOT NULL COMMENT '管理员ID',
  `username` varchar(50) NOT NULL COMMENT '管理员账号',
  `wxnum` varchar(255) NOT NULL COMMENT '微信号',
  `path` varchar(255) NOT NULL COMMENT 'URL路径',
  `account` varchar(32) DEFAULT NULL COMMENT '推广户',
  `company` varchar(32) NOT NULL COMMENT '版权',
  `toji` varchar(255) DEFAULT '' COMMENT '百度统计',
  `status` int(1) unsigned DEFAULT NULL,
  `create_time` int(10) unsigned DEFAULT NULL COMMENT '创建时间',
  `update_time` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `a_title` (`id`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COMMENT='文章表';

-- -----------------------------
-- Records of `think_article`
-- -----------------------------
INSERT INTO `think_article` VALUES ('1', '1', 'admin', 'wx123&wx456&wx789', 'http://wx.tystzl.cn/', '头条youtnn@kaifeng.com', '多燕瘦', '', '', '1597814921', '1597814921');

-- -----------------------------
-- Table structure for `think_auth_group`
-- -----------------------------
DROP TABLE IF EXISTS `think_auth_group`;
CREATE TABLE `think_auth_group` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `title` char(100) NOT NULL DEFAULT '',
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `rules` text NOT NULL,
  `create_time` int(11) DEFAULT NULL,
  `update_time` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `think_auth_group`
-- -----------------------------
INSERT INTO `think_auth_group` VALUES ('1', '超级管理员', '1', '', '1', '1');
INSERT INTO `think_auth_group` VALUES ('2', '运营优化师', '1', '5,6,7,8,24,26,44,45,46,47,86,87,88', '1561800125', '1597824030');

-- -----------------------------
-- Table structure for `think_auth_group_access`
-- -----------------------------
DROP TABLE IF EXISTS `think_auth_group_access`;
CREATE TABLE `think_auth_group_access` (
  `uid` mediumint(8) unsigned NOT NULL,
  `group_id` mediumint(8) unsigned NOT NULL,
  UNIQUE KEY `uid_group_id` (`uid`,`group_id`) USING BTREE,
  KEY `uid` (`uid`) USING BTREE,
  KEY `group_id` (`group_id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `think_auth_group_access`
-- -----------------------------
INSERT INTO `think_auth_group_access` VALUES ('1', '1');
INSERT INTO `think_auth_group_access` VALUES ('2', '2');
INSERT INTO `think_auth_group_access` VALUES ('3', '2');
INSERT INTO `think_auth_group_access` VALUES ('5', '2');
INSERT INTO `think_auth_group_access` VALUES ('6', '2');
INSERT INTO `think_auth_group_access` VALUES ('7', '2');
INSERT INTO `think_auth_group_access` VALUES ('8', '2');
INSERT INTO `think_auth_group_access` VALUES ('9', '2');
INSERT INTO `think_auth_group_access` VALUES ('10', '2');
INSERT INTO `think_auth_group_access` VALUES ('11', '2');
INSERT INTO `think_auth_group_access` VALUES ('12', '2');
INSERT INTO `think_auth_group_access` VALUES ('13', '2');
INSERT INTO `think_auth_group_access` VALUES ('14', '2');

-- -----------------------------
-- Table structure for `think_auth_rule`
-- -----------------------------
DROP TABLE IF EXISTS `think_auth_rule`;
CREATE TABLE `think_auth_rule` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` char(80) NOT NULL DEFAULT '',
  `title` char(20) NOT NULL DEFAULT '',
  `type` tinyint(1) NOT NULL DEFAULT '1',
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `css` varchar(20) NOT NULL COMMENT '样式',
  `condition` char(100) NOT NULL DEFAULT '',
  `pid` int(11) NOT NULL DEFAULT '0' COMMENT '父栏目ID',
  `sort` int(11) NOT NULL DEFAULT '0' COMMENT '排序',
  `create_time` int(11) NOT NULL DEFAULT '0' COMMENT '添加时间',
  `update_time` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=89 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `think_auth_rule`
-- -----------------------------
INSERT INTO `think_auth_rule` VALUES ('1', '#', '系统管理', '1', '1', 'fa fa-gear', '', '0', '2', '1446535750', '1477312169');
INSERT INTO `think_auth_rule` VALUES ('2', 'admin/user/index', '用户管理', '1', '1', '', '', '1', '10', '1446535750', '1477312169');
INSERT INTO `think_auth_rule` VALUES ('3', 'admin/role/index', '角色管理', '1', '1', '', '', '1', '20', '1446535750', '1477312169');
INSERT INTO `think_auth_rule` VALUES ('4', 'admin/menu/index', '菜单管理', '1', '1', '', '', '1', '30', '1446535750', '1477312169');
INSERT INTO `think_auth_rule` VALUES ('5', '#', '数据库管理', '1', '1', 'fa fa-database', '', '0', '3', '1446535750', '1477312169');
INSERT INTO `think_auth_rule` VALUES ('6', 'admin/data/index', '数据库备份', '1', '1', '', '', '5', '50', '1446535750', '1477312169');
INSERT INTO `think_auth_rule` VALUES ('7', 'admin/data/optimize', '优化表', '1', '1', '', '', '6', '50', '1477312169', '1477312169');
INSERT INTO `think_auth_rule` VALUES ('8', 'admin/data/repair', '修复表', '1', '1', '', '', '6', '50', '1477312169', '1477312169');
INSERT INTO `think_auth_rule` VALUES ('9', 'admin/user/useradd', '添加用户', '1', '1', '', '', '2', '50', '1477312169', '1477312169');
INSERT INTO `think_auth_rule` VALUES ('10', 'admin/user/useredit', '编辑用户', '1', '1', '', '', '2', '50', '1477312169', '1477312169');
INSERT INTO `think_auth_rule` VALUES ('11', 'admin/user/userdel', '删除用户', '1', '1', '', '', '2', '50', '1477312169', '1477312169');
INSERT INTO `think_auth_rule` VALUES ('12', 'admin/user/user_state', '用户状态', '1', '1', '', '', '2', '50', '1477312169', '1477312169');
INSERT INTO `think_auth_rule` VALUES ('13', '#', '日志管理', '1', '1', 'fa fa-tasks', '', '0', '6', '1477312169', '1477312169');
INSERT INTO `think_auth_rule` VALUES ('14', 'admin/log/operate_log', '日志列表', '1', '1', '', '', '13', '50', '1477312169', '1559123623');
INSERT INTO `think_auth_rule` VALUES ('22', 'admin/log/del_log', '删除日志', '1', '1', '', '', '14', '50', '1477312169', '1477316778');
INSERT INTO `think_auth_rule` VALUES ('24', '#', '推广管理', '1', '1', 'fa fa-paste', '', '0', '1', '1477312169', '1559117468');
INSERT INTO `think_auth_rule` VALUES ('26', 'admin/article/index', '微信号列表', '1', '1', '', '', '24', '20', '1477312333', '1559117492');
INSERT INTO `think_auth_rule` VALUES ('27', 'admin/data/import', '数据库还原', '1', '1', '', '', '5', '50', '1477639870', '1477639870');
INSERT INTO `think_auth_rule` VALUES ('28', 'admin/data/revert', '还原', '1', '1', '', '', '27', '50', '1477639972', '1477639972');
INSERT INTO `think_auth_rule` VALUES ('29', 'admin/data/del', '删除', '1', '1', '', '', '27', '50', '1477640011', '1477640011');
INSERT INTO `think_auth_rule` VALUES ('30', 'admin/role/roleAdd', '添加角色', '1', '1', '', '', '3', '50', '1477640011', '1477640011');
INSERT INTO `think_auth_rule` VALUES ('31', 'admin/role/roleEdit', '编辑角色', '1', '1', '', '', '3', '50', '1477640011', '1477640011');
INSERT INTO `think_auth_rule` VALUES ('32', 'admin/role/roleDel', '删除角色', '1', '1', '', '', '3', '50', '1477640011', '1477640011');
INSERT INTO `think_auth_rule` VALUES ('33', 'admin/role/role_state', '角色状态', '1', '1', '', '', '3', '50', '1477640011', '1477640011');
INSERT INTO `think_auth_rule` VALUES ('34', 'admin/role/giveAccess', '权限分配', '1', '1', '', '', '3', '50', '1477640011', '1477640011');
INSERT INTO `think_auth_rule` VALUES ('35', 'admin/menu/add_rule', '添加菜单', '1', '1', '', '', '4', '50', '1477640011', '1477640011');
INSERT INTO `think_auth_rule` VALUES ('36', 'admin/menu/edit_rule', '编辑菜单', '1', '1', '', '', '4', '50', '1477640011', '1477640011');
INSERT INTO `think_auth_rule` VALUES ('37', 'admin/menu/del_rule', '删除菜单', '1', '1', '', '', '4', '50', '1477640011', '1477640011');
INSERT INTO `think_auth_rule` VALUES ('38', 'admin/menu/rule_state', '菜单状态', '1', '1', '', '', '4', '50', '1477640011', '1477640011');
INSERT INTO `think_auth_rule` VALUES ('39', 'admin/menu/ruleorder', '菜单排序', '1', '1', '', '', '4', '50', '1477640011', '1477640011');
INSERT INTO `think_auth_rule` VALUES ('44', 'admin/article/add_article', '添加', '1', '1', '', '', '26', '50', '1477640011', '1477640011');
INSERT INTO `think_auth_rule` VALUES ('45', 'admin/article/edit_article', '编辑', '1', '1', '', '', '26', '50', '1477640011', '1477640011');
INSERT INTO `think_auth_rule` VALUES ('46', 'admin/article/del_article', '删除', '1', '1', '', '', '26', '50', '1477640011', '1477640011');
INSERT INTO `think_auth_rule` VALUES ('47', 'admin/article/details', '详情', '1', '1', '', '', '26', '50', '1477640011', '1561449115');
INSERT INTO `think_auth_rule` VALUES ('61', 'admin/config/index', '配置管理', '1', '1', '', '', '1', '50', '1479908607', '1479908607');
INSERT INTO `think_auth_rule` VALUES ('62', 'admin/config/index', '配置列表', '1', '1', '', '', '61', '50', '1479908607', '1487943813');
INSERT INTO `think_auth_rule` VALUES ('63', 'admin/config/save', '保存配置', '1', '1', '', '', '61', '50', '1479908607', '1487943831');
INSERT INTO `think_auth_rule` VALUES ('86', 'admin/article/today', '今日数据下载', '1', '1', '', '', '26', '50', '1563263506', '1563263506');
INSERT INTO `think_auth_rule` VALUES ('87', 'admin/article/yesterday', '昨天数据下载', '1', '1', '', '', '26', '50', '1563263546', '1563263546');
INSERT INTO `think_auth_rule` VALUES ('88', 'admin/article/excel', '全部数据下载', '1', '1', '', '', '26', '50', '1563263587', '1563263587');

-- -----------------------------
-- Table structure for `think_config`
-- -----------------------------
DROP TABLE IF EXISTS `think_config`;
CREATE TABLE `think_config` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '配置ID',
  `name` varchar(30) NOT NULL DEFAULT '' COMMENT '配置名称',
  `value` text COMMENT '配置值',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_name` (`name`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `think_config`
-- -----------------------------
INSERT INTO `think_config` VALUES ('1', 'web_site_title', '微信号复制统计后台');
INSERT INTO `think_config` VALUES ('2', 'web_site_description', '微信号复制统计后台');
INSERT INTO `think_config` VALUES ('3', 'web_site_keyword', '微信号复制统计后台');
INSERT INTO `think_config` VALUES ('4', 'web_site_icp', '粤ICP备00000000号-1');
INSERT INTO `think_config` VALUES ('5', 'web_site_cnzz', '');
INSERT INTO `think_config` VALUES ('6', 'web_site_copy', 'Copyright © 2020 Kaifeng All rights reserved.');
INSERT INTO `think_config` VALUES ('7', 'web_site_close', '1');
INSERT INTO `think_config` VALUES ('8', 'list_rows', '30');
INSERT INTO `think_config` VALUES ('9', 'admin_allow_ip', '');
INSERT INTO `think_config` VALUES ('10', 'alisms_appkey', '');
INSERT INTO `think_config` VALUES ('11', 'alisms_appsecret', '');
INSERT INTO `think_config` VALUES ('12', 'alisms_signname', '');

-- -----------------------------
-- Table structure for `think_log`
-- -----------------------------
DROP TABLE IF EXISTS `think_log`;
CREATE TABLE `think_log` (
  `log_id` int(11) NOT NULL AUTO_INCREMENT,
  `admin_id` int(11) DEFAULT NULL COMMENT '用户ID',
  `admin_name` varchar(50) DEFAULT NULL COMMENT '用户姓名',
  `description` varchar(300) DEFAULT NULL COMMENT '描述',
  `ip` char(60) DEFAULT NULL COMMENT 'IP地址',
  `status` tinyint(1) DEFAULT NULL COMMENT '1 成功 2 失败',
  `add_time` int(11) DEFAULT NULL COMMENT '添加时间',
  PRIMARY KEY (`log_id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `think_log`
-- -----------------------------
INSERT INTO `think_log` VALUES ('1', '1', 'admin', '用户【admin】登录成功', '127.0.0.1', '1', '1569550225');
INSERT INTO `think_log` VALUES ('2', '1', 'admin', '用户【admin】登录成功', '219.137.140.117', '1', '1597813846');
INSERT INTO `think_log` VALUES ('3', '1', 'admin', '用户【admin】登录成功', '219.137.140.117', '1', '1597819233');
INSERT INTO `think_log` VALUES ('4', '1', 'admin', '用户【admin】登录成功', '219.137.140.117', '1', '1597826107');

-- -----------------------------
-- Table structure for `think_monitor`
-- -----------------------------
DROP TABLE IF EXISTS `think_monitor`;
CREATE TABLE `think_monitor` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `ipAddr` varchar(20) NOT NULL COMMENT 'IP',
  `address` varchar(15) DEFAULT NULL COMMENT 'ip地址',
  `engine` varchar(255) DEFAULT NULL COMMENT '搜索引擎',
  `account` varchar(255) DEFAULT NULL COMMENT '信息框架',
  `emp` int(10) unsigned NOT NULL COMMENT '管理员ID',
  `ope` varchar(10) DEFAULT NULL,
  `wxnum` varchar(255) DEFAULT NULL COMMENT '微信号',
  `keyword` varchar(2048) DEFAULT NULL COMMENT '关键词',
  `createtime` varchar(30) DEFAULT NULL COMMENT '复制时间',
  `uid` int(10) unsigned DEFAULT NULL,
  `url` varchar(255) DEFAULT NULL COMMENT 'url',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `think_monitor`
-- -----------------------------
INSERT INTO `think_monitor` VALUES ('1', '219.137.140.117', '广东省广州市天河区', 'Null', '头条youtnn@kaifeng.com', '1', 'oncopy', 'wx456', '无法获取', '1597816299', '1', 'http://wx.tystzl.cn/');
INSERT INTO `think_monitor` VALUES ('2', '219.137.140.117', '广东省广州市天河区', 'Null', '头条youtnn@kaifeng.com', '1', 'oncopy', 'wx123', '无法获取', '1597818604', '1', 'http://wx.tystzl.cn/');
INSERT INTO `think_monitor` VALUES ('3', '219.137.140.117', '广东省广州市天河区', 'Null', '头条youtnn@kaifeng.com', '1', 'oncopy', 'wx789', '无法获取', '1597818631', '1', 'http://wx.tystzl.cn/');
INSERT INTO `think_monitor` VALUES ('4', '219.137.140.117', '广东省广州市天河区', 'Null', '头条youtnn@kaifeng.com', '1', 'oncopy', 'wx456', '无法获取', '1597819700', '1', 'http://wx.tystzl.cn/');
INSERT INTO `think_monitor` VALUES ('5', '219.137.140.117', '广东省广州市天河区', 'Null', '头条youtnn@kaifeng.com', '1', 'oncopy', 'wx123', '无法获取', '1597819769', '1', 'http://wx.tystzl.cn/');
INSERT INTO `think_monitor` VALUES ('6', '183.40.214.166', '广东省广州市', 'Null', '头条youtnn@kaifeng.com', '1', 'ontouch', 'wx789', '无法获取', '1597820124', '1', 'http://wx.tystzl.cn/');
INSERT INTO `think_monitor` VALUES ('7', '219.137.140.117', '广东省广州市天河区', 'Null', '头条youtnn@kaifeng.com', '1', 'oncopy', 'wx789', '无法获取', '1597820442', '1', 'http://wx.tystzl.cn/');
INSERT INTO `think_monitor` VALUES ('8', '219.137.140.117', '广东省广州市天河区', 'Null', '头条youtnn@kaifeng.com', '1', 'oncopy', 'wx123', '无法获取', '1597821142', '1', 'http://wx.tystzl.cn/');
